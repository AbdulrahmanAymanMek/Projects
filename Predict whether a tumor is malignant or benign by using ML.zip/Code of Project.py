import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.impute import SimpleImputer

# Function to get user input for the features
def get_user_input():
    features = [
        'radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean',
        'compactness_mean', 'concavity_mean', 'concave_points_mean', 'symmetry_mean', 'fractal_dimension_mean',
        'radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se',
        'compactness_se', 'concavity_se', 'concave_points_se', 'symmetry_se', 'fractal_dimension_se',
        'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 'smoothness_worst',
        'compactness_worst', 'concavity_worst', 'concave_points_worst', 'symmetry_worst', 'fractal_dimension_worst'
    ]

    user_input = []

    print("How would you like to enter the values?")
    print("1. One by one")
    print("2. In a single line separated by spaces")
    choice = int(input("Enter the number of your choice: "))

    if choice == 1:
        for feature in features:
            value = float(input(f"Enter value for {feature}: "))
            user_input.append(value)
    elif choice == 2:
        print("Enter the values in a single line separated by spaces:")
        values = input()
        user_input = list(map(float, values.split()))
    else:
        print("Invalid choice. Exiting...")
        return None

    return user_input

# Load the dataset
file_path = r'C:\Users\Whz\Downloads\data.csv'
data = pd.read_csv(file_path)

# Preprocessing: Map diagnosis labels to numerical values (M -> 1, B -> 0)
data['diagnosis'] = data['diagnosis'].map({'M': 1, 'B': 0})
# Separate features and target variable
X = data.drop(columns=['id', 'diagnosis'])
y = data['diagnosis']

# Fill missing values using SimpleImputer with mean strategy
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_imputed, y, test_size=0.3, random_state=42)

# Create and train a logistic regression model
log_reg = LogisticRegression(max_iter=10000)
log_reg.fit(X_train, y_train)

# Make predictions on the test set
y_pred = log_reg.predict(X_test)

# Evaluate the model's performance using accuracy, confusion matrix, and classification report
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")

conf_matrix = confusion_matrix(y_test, y_pred)
print(f"Confusion Matrix:\n{conf_matrix}")

report = classification_report(y_test, y_pred)
print(f"Classification Report:\n{report}")

# Get user input for features and make a prediction using the trained model
user_input = get_user_input()

if user_input is not None:
    user_prediction = log_reg.predict([user_input])

    # Print the predicted diagnosis
    diagnosis = "Malignant" if user_prediction[0] == 1 else "Benign"
    print(f"The predicted diagnosis is: {diagnosis}")
else:
    print("No input provided.")